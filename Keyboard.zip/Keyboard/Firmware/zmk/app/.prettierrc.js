module.exports = {
    endOfLine: "auto",
};
