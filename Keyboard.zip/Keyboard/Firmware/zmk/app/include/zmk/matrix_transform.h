/*
 * Copyright (c) 2020 The ZMK Contributors
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

uint32_t zmk_matrix_transform_row_column_to_position(uint32_t row, uint32_t column);