/*
 * Copyright (c) 2021 The ZMK Contributors
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

enum zmk_endpoint {
    ZMK_ENDPOINT_USB,
    ZMK_ENDPOINT_BLE,
};
