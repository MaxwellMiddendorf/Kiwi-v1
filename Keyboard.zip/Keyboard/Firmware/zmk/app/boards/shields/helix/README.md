#### Note to user:

- If desired, RGB underglow must be manually enabled before building and flashing. Check 'helix.conf' to do so.
- Peripheral RGB function is impaired until full support is implemented in the master branch.
- OLED displays are not currently included in this shield. This will be updated after OLED support is live.
- 'KANA' and 'EISUU' input is currently utilized under the 'LANG1' and 'LANG2' keycodes respectively.

---

Thanks to Nicell, KemoNine, petejohanson, TJ "Chormbo The Great", joelspadin/Rinh, Wofiel, Okke, innovaker,
and the rest of the ZMK contributors for their support in constructing this shield. I appreciate your assistance greatly.
This has been a valuable learning experience for me. May this contribution serve the community well.
