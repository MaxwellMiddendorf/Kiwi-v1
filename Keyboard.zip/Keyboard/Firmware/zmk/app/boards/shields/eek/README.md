A fixed split 36key-board with a typing angle of 90 degrees distributed by cbkbd
