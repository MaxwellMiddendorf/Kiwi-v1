# [Makerdiary M60](https://wiki.makerdiary.com/m60)

A 60% ANSI keyboard designed and manufactured by Makerdiary.
http://makerdiary.com

## Features

- Per key RGB LED.
- Uses makerdiary M.2 nRF52840 module
- Matrix wiring

## Hardware Notes

https://wiki.makerdiary.com/m60/developer_guide/hardware/
