# [BFO-9000](https://keeb.io/products/bfo-9000-keyboard-customizable-full-size-split-ortholinear)

Customizable full-size split ortholinear.

## Features

* Compatible with MX-compatible, Alps-compatible, and Kailh Low-Profile Choc switches.
* Breakoff pieces to allow for 4 to 6 rows and 7 to 9 columns.
* RGB LED connections

## Hardware Notes

[Included default keymap](http://www.keyboard-layout-editor.com/#/gists/51293c31afcd5f1765e8f413a46bfcf8)