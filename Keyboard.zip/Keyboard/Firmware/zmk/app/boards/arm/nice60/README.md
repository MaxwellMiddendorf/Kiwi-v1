# nice!60
![nice!60](https://i.imgur.com/0YWv5PE.png)

The nice!60 is a hotswap 60% made by Nice Keyboards. https://nicekeyboards.com/nice-60

## Building nice!60 ZMK firmware
```
west build -p -b nice60
```
