/*
 * Copyright (c) 2020 The ZMK Contributors
 *
 * SPDX-License-Identifier: CC-BY-NC-SA-4.0
 */

export const genericDesktop = 0x01;
export const key = 0x07;
export const consumer = 0x0c;
