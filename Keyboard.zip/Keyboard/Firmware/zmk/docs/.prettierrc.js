module.exports = {
  endOfLine: "auto",
};
